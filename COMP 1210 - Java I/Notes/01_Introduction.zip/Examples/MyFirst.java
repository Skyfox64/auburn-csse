/**
*  Simple class to print to standard out.
*  @author J. Cross
*/
public class MyFirst 
{
/**
	Prints War Eagle multiple times.
	@param args Unused command line parameters.
*/
   public static void main(String[] args)
   {
   // this is simple comment to the end of the line
   // another comment 
   /*
     multiline comment
     
     
     */
      System.out.println("War Eagle!");
      System.out.println("War Eagle!!");
      System.out.println("War Eagle!!!");
   }

}