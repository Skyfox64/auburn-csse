import java.awt.*;
import java.applet.*; 
public class WarEagleApplet extends Applet
{
   public void paint (Graphics page)
   {
      page.setColor(Color.RED);
      page.drawString("War Eagle!", 40, 40);
   }
}
