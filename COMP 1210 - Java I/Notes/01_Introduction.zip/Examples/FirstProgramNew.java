/**
 * Prints War Eagle three times.
*/ 

   public class FirstProgramNew
   {
   /**
    *
    * @param args (not used)
   */
   	
      public static void main(String[] args)
      {
         System.out.println("War Eagle!");
         // single line comment
      	//
      	/* this is a multi-line 
      	   comment
      		slfslfjdsf
      	*/	
         System.out.println("War Eagle!!");
         System.out.println("War Eagle!!!");
      }
   }