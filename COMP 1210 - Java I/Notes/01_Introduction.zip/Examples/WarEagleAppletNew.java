   import java.awt.*;
   import java.applet.*; 
   public class WarEagleAppletNew extends Applet
   {
      public void paint (Graphics page)
      {
         page.drawString("War Eagle!", 20, 20);
      }
   }
