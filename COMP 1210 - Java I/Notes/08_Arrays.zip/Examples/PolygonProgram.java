public class PolygonProgram {

   public static void main(String[] args) {
   
      double[] sides = {5.4, 2.3, 5.7, 4.5};
      Polygon shape = new Polygon(sides);
      System.out.println(shape);
   }
}