public class Loan {

   public Loan(int accountType) {
   
   }
   
   public double getBalance() {
      return 0; 
   }
   
   public boolean setInterest(double newInterest) {
      return false;
   }
   	
   public boolean borrow(double amount) {
      return false;
   }
   
   public double calculateTotalBalance() {
      return 0;
   }

   public String toString() {
      return null;
   }
}
