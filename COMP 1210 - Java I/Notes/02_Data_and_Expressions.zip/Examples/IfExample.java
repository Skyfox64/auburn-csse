   public class IfExample
   {
      public static void main(String[] args)
      {
         int temp = 39;
         if (temp < 50) {
            System.out.println("It's cold!"); 
         }
         System.out.println("Temp = " + temp); 
      
      }
   }