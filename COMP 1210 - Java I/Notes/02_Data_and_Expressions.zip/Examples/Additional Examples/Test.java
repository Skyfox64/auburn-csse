   import java.util.Scanner;
   import javax.swing.*;
/**
 * Test.java produces good things.
 */
    public class Test 
   {
   /** 
    * Produces good things.
    */
       public static void main(String[]args)
      {
         for(int i=0;i<10;i++)
         {
            int z = i*i;
            System.out.println(i + "  " + z);
         }
         new JFrame().show();
      
      }
   
   }
