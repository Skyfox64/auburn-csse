    class One {
       static public void main(String[] arg) {
         float x = (float)7.0e-45; 
         System.out.println("Hi");
         float y = (float) 1.0000006 * (float) Math.pow(2,-127);
         double z = 1.0000006 * Math.pow(2,-127);
         int i = (int) x * (int) x;
         boolean found = true;
         found = false;
      }
   }