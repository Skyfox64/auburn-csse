/**
 * Declares and intializes an example of each 
 * primitive type.  Set a breakpoint, run Debug 
 * and then open a viewer on each variable.  
 * Set the viewer to "Detail" view.
 */
    public class TypesExample2
   {
       public static void main(String[]args)
      {
         byte b = 15;
         short s = 15;
         int i = 15;
         long j = 15;
      	
         float x = 999;
         double y = 999;
      	
         char c = 'A';
      	
         boolean bn = true;
         
         float sides = 2122112.6121f;
         System.out.println ("There are: " + sides + " sides");
      
         double sides2 = 2122112.6121d;
         System.out.println ("There are: " + sides2 + " sides");
      
      
      }
   }