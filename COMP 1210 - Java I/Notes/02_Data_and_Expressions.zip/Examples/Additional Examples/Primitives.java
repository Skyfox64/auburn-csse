//********************************************************************
//  CountOff.java       Author: J. Cross
//
//  Demonstrates the difference between print and println.
//********************************************************************

    public class Primitives
   {
   //-----------------------------------------------------------------
   //  Prints down the page then across.
   //-----------------------------------------------------------------
       public static void main (String[] args)
      {
         byte i = 123;
         short j = 1234;
         int k = 1234;
         long l = 1234;
         float x = 1234;
         double y = 1234; 
         char c = '3';
         System.out.println ("end");
      }
   }
