/**
 *  Demonstrates type promotion.
 */
   public class Question12
   {
      public static void main (String[] args)
      {           
         double x = 4;
         int i = 5;
         double answer = (x/i) * 2;
         System.out.println(answer);
      }
   }
