/**
 * Demonstrates the delcaration and initialization
 * of variables. 
 */
public class VariablesExample
{
   /**
    * Examples of variable declaration and initialization.
    *   @param args - Standard commandline arguments
    */
   public static void main(String[] args)
   {
   // Declaring integer (int) variables.
      int j; 
   
   // Declaring and initializing integer (int) variables.
      int m = 0;
      int n = 10, p = 20;
   	
      System.out.println("m = " + m);
      System.out.println("n = " + n);
      System.out.println("p = " + p);
      j = 9999;
      System.out.println("j = " + j);
   }
}
