function connectToSession()
{
	$(".loadingMsg").fadeOut();
	$(".connectingMsg").delay(800).css("visibility", "visible").fadeIn("slow");
}

function lessonReady()
{
	$(".connectingMsg").fadeOut();
	$(".readyMsg").delay(800).css("visibility", "visible").fadeIn();
}

//after 2 seconds, call connectToSession
setTimeout(connectToSession, 2000);
setTimeout(loadWelcome, 5000);

function loadWelcome()
{
	window.location="../Tutor/welcome.html";
}