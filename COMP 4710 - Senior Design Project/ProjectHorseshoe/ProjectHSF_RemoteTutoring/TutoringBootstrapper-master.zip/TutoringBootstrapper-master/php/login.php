<?php
session_start();

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

// User Input
$username = trim($_POST['usernameForm']);

if($username === NULL)
{
	header("Location: /index.html");
}

// Connect to database
$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

// Get corresponding password for username 
$query = "SELECT * FROM users WHERE username = '$username';";
$result= $con->query($query);

$userInfo = $result->fetch_array(MYSQLI_ASSOC);
$userId = $userInfo["id"];
$userFirstName = $userInfo["first_name"];
$userType = $userInfo["type"];

// if username is invalid, display error message
if(!$userInfo || $username === NULL || empty($username))
{
	header("Location: /index.html?success='false'");
}
// if user is not a student, bring to password page
elseif($userType !== 'student')
{
	header("Location: /secured.html");
}
// everything checks out, go to welcome page
else
{
	$successQuery = "UPDATE users SET online = '1' WHERE id = '$userId';";
	$result1 = $con->query($successQuery);
	header("Location: /php/lessonHistory.php");
}

mysqli_close($con);

$_SESSION['username'] = $username;
$_SESSION['userID'] = $userId;

?>
