<?php

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$attendance = $_REQUEST['attendance'];
$id = $_REQUEST['userId'];

$query = "UPDATE users ";
$query .= "SET online = $attendance ";
$query .= "WHERE id = $id";
$tutors = $con->query($query);

mysqli_close($con);

?>