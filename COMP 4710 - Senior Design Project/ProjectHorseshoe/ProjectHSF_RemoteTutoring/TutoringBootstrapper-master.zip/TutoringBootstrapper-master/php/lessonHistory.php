<?php
session_start();
// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$username = $_SESSION['username'];
$userID = $_SESSION['userID'];

// Connect to database
$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

// Get corresponding password for username 
$query = "SELECT name, type FROM past_lesson WHERE student_id = $userID";
$result= $con->query($query);

$pastLessonInfo = $result->fetch_array(MYSQLI_ASSOC);

$taskName = $pastLessonInfo["name"];
$type = $pastLessonInfo["type"];

mysqli_close($con);

header("Location: /welcome.html?name=$username&type=$type&task=$taskName");

?>
