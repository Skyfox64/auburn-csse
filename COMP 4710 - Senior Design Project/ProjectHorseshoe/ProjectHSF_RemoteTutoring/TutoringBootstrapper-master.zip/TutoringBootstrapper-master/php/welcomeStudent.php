<?php
session_start();

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$userID = $_SESSION['userID'];

// Connect to database
$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$query = "SELECT subject, type, resource FROM recommendations WHERE student_id = '$userID';";
$result= $con->query($query);

$recommendationInfo = $result->fetch_array(MYSQLI_ASSOC);

$subject = $recommendationInfo["subject"];
$type = $recommendationInfo["type"];
$resource = $recommendationInfo["resource"];

mysqli_close($con);

$directory = "";
if($type == 'pdf')
{
	if($subject == 'math')
	{
		$directory = "/worksheets/math/" . $resource;
		echo $directory;
	}
	elseif($subject == 'reading')
	{
		$directory = "/worksheets/reading/" . $resource;
		echo $directory;
	}
}
else
{
	echo $resource;
}
?>
