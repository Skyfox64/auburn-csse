<?php
session_start();

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

// User Input
$username = $_SESSION['username'];
$password = $_POST['passwordForm'];

// Connect to database
$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

// Get corresponding password for username 
$query = "SELECT * FROM users WHERE username = '$username';";
$result= $con->query($query);

$userInfo = $result->fetch_array(MYSQLI_ASSOC);

$userId = $userInfo["id"];
$userType = $userInfo["type"];
$userFirstName = $userInfo["first_name"];
$retrievedPassword = $userInfo["password"];

$successQuery = "UPDATE users SET online = '1' WHERE id = '$id';";
$result1 = $con->query($successQuery);

mysqli_close($con);

if($password == $retrievedPassword)
{
	if($userType == 'leader')
	{
		header("Location: /php/recommendation.php");
	}
	else if($userType == 'admin')
	{
		header("Location: /php/welcomeAdmin.php");
	}
	else if($userType == 'tutor')
	{
		header("Location: ../waiting.html");
	}
}
else if ($userType == 'student')
{
	header("Location: /secured.html?success='false'");
}



?>
