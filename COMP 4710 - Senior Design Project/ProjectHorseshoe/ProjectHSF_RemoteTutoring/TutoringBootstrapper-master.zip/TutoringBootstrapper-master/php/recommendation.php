<?php
session_start();
// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$userId = $_SESSION['userID'];

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$studentQuery = "SELECT id, first_name, last_name ";
$studentQuery .= "FROM users ";
$studentQuery .= "WHERE type = 'student' ";
$studentQuery .= "AND leader = $userId ";
$studentQuery .= "ORDER BY last_name;";
$students = $con->query($studentQuery);


?>

<!DOCTYPE html>
<meta charset="UTF-8">

<html>
	<head>
		<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
		<meta content="utf-8" http-equiv="encoding">
		<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="/css/superhero.css"/>
		<link rel="stylesheet" type="text/css" href="/css/horseshoe.css"/>
		<title>
			Welcome!
		</title>
	</head>
	<body>
	
		<div class="container">
			<div class="row">
				<h1 style="text-align:center">Team Recommendations</h1>
			</div>
			<div class="row">
				<div class="well vertical-align col-xs-8 welcomeSummary">
				<!-- Dear Group: If you want a radio button here instead, good luck. -->
				<div style="margin-bottom:30px;text-align:center;">
					<label>Math or Reading :</label>
					<?php
						// Get a student to determine if math or reading day
						$resourceQuery = "SELECT subject FROM recommendations;";
						$recommedations = $con->query($resourceQuery);
						$recommedation = $recommedations->fetch_array(MYSQLI_ASSOC);
						$subject = $recommedation['subject'];
						echo "<select id='subjectSelect'>";
						echo "<option value='math'";
						if($subject == 'math')
						{
							echo "selected='selected'";
						}
						echo ">Math</option>";
						echo "<option value='reading'";
						if($subject == 'reading')
						{
							echo "selected='selected'";
						}
						echo ">Reading</option>";
						echo "</select>";
					?>
				</div>
 					<table class="table table-bordered table-hover">
						<thead>
							<tr>
								<th>Child</th>
								<th>PDF/Link</th>
								<th>Resource</th>
								<th></th>
							</tr>
						</thead>
						<tbody>
						<?php
							$mathWorksheetDir = '../worksheets/math';
							$mathWorksheets = scandir($mathWorksheetDir);
							$numMathWorksheets = count($mathWorksheets);
							
							$readWorksheetDir = '../worksheets/reading';
							$readWorksheets = scandir($readWorksheetDir);
							$numReadWorksheets = count($readWorksheets);
							
							while ($student = $students->fetch_array(MYSQLI_ASSOC))
							{
								$studentId = $student['id'];
								$rowId = "student" . $studentId;
								$lastName = ucfirst($student['last_name']);
								$firstName = ucfirst($student['first_name']);
								
								// Get student's current recommendation
								$resourceQuery = "SELECT type, resource FROM recommendations WHERE student_id = $studentId;";
								$recommedations = $con->query($resourceQuery);
								$recommedation = $recommedations->fetch_array(MYSQLI_ASSOC);
								
								echo "<tr id=$rowId>";
								
								// Child
								echo "<td>$lastName, $firstName</td>";
								
								// PDF vs Link
								echo "<td><select class='resourceType'>";
								echo "<option value='pdf'";
								// Set dropdown to value of type stored in table
								$dailySubject = $recommedation["type"];
								if($dailySubject == "pdf")
								{
									echo "selected='selected'";
								}
								echo ">PDF</option>";
								echo "<option value='link'";
								if($dailySubject == 'link')
								{
									echo "selected='selected'";
								}
								echo ">Link</option>";
								echo "</select></td>";
								
								//Resource
								echo "<td>";
								// Set input or dropdown to value of type stored in table (depends on selected type)
								$recommendedResource = $recommedation['resource'];
								if($dailySubject == 'link')
								{
									echo "<input class='resourceText col-xs-10' type='text'";
									echo "value=$recommendedResource";
									echo "></input>";
									echo "<select class='resourceDrop' style='display:none;'>";
								}
								else if($dailySubject == 'pdf')
								{
									echo "<input class='resourceText col-xs-10' type='text' maxlength='300' style='display:none;'></input>";
									echo "<select class='resourceDrop'>";
								}
								
								// populate dropdown, start at two to get real worksheet names
								for($i = 2; $i < $numMathWorksheets; $i++)
								{
									$worksheetName = $mathWorksheets[$i];
									echo "<option value=$mathWorksheets[$i] class='$worksheetName' ";
									if($dailySubject == 'pdf' && $recommendedResource == $worksheetName)
									{
										echo "selected='selected'";
									}
									echo ">$mathWorksheets[$i]</option>";
								}
								echo "</select>";
								echo "</td>";
								
								//Update
								echo "<td><button class='btn btn-xs btn-success updateBtn'>Update</button>";
								
								echo "</tr>";
							}
							mysqli_close($con);
						?>
						</tbody>
					</table>
				</div> <!--well-->
			</div> <!--row-->
		</div> <!--container-->
	</body>
	<footer>
		<script src="/js/jquery2.2.0.js"></script>
		<script src="/js/recommendation.js"></script>
	</footer>
</html>
							
		