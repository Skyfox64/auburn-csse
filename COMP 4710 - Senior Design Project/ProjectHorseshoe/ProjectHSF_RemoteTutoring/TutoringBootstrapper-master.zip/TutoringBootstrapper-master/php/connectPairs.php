<?php
// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

if ($connecting == 1){//If establishing a connection
	//Set partner for child
	$query1 = "UPDATE users ";
	$query1 .= "SET partner = $tutorId ";
	$query1 .= "WHERE id = $childId;";
	$tutors = $con->query($query1);

	//Set partner for tutor
	$query2 = "UPDATE users ";
	$query2 .= "SET partner = $childId ";
	$query2 .= "WHERE id = $tutorId;";
	$tutors = $con->query($query2);
} else {//If ending a connection
	//Set partner for child
	$query1 = "UPDATE users ";
	$query1 .= "SET partner = 0 ";
	$query1 .= "WHERE id = $childId;";
	$tutors = $con->query($query1);

	//Set partner for tutor
	$query2 = "UPDATE users ";
	$query2 .= "SET partner = 0 ";
	$query2 .= "WHERE id = $tutorId;";
	$tutors = $con->query($query2);
}

mysqli_close($con);

?>