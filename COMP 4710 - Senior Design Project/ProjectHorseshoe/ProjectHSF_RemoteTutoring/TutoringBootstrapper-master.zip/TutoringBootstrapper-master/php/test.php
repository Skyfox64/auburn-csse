<?php

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;
//mysqli_connect('localhost',$username,$password);

$con = mysqli_connect('localhost',$username,$password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());


//@mysqli_select_db($database) or die( "Unable to select database");
//echo "DB Connected successfully";

//$query = "INSERT INTO phsf.phsf_users VALUES ('', 'student', 'john','smith','john',NULL,'0')";
$query = "SELECT * FROM users;";
//$query = ("CREATE TABLE test (id NUMBER(5));");
//$

//mysqli_query($con, $query, $result);

$result= $con->query($query);

//while($row=mysqli_fetch)

$row = $result->fetch_array(MYSQLI_ASSOC);
$row2 = $result->fetch_array(MYSQLI_ASSOC);
printf("%s %s %s\n", $row["id"], $row["type"], $row["first_name"]);
printf("%s %s %s\n", $row2["id"], $row2["type"], $row2["first_name"]);

//echo "$row[0], $row[1], $row[2]";	

//if($result)
//{
//	echo $result;
//}
//else
//{
//	echo $result;
//	echo "You are SUPER? dead\n";
//}
	//echo "New record created successfully";

mysqli_close($con);

?>