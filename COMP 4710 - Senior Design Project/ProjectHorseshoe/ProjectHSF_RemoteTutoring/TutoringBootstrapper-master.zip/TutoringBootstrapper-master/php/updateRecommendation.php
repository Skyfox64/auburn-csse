<?php
session_start();
// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$studentId = $_REQUEST['id'];
$recommendation = $_REQUEST['resource'];

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

//change thing
$query = "UPDATE recommendations ";
$query .= "SET resource = '$recommendation' ";
$query .= "WHERE student_id = $studentId;";

$result=$con->query($query);

echo $recommendation;

mysqli_close($con);
?>