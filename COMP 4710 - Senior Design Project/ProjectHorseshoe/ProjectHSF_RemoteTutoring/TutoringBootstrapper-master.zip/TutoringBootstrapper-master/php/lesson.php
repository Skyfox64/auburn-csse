<?php
session_start();


// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$recommendationKey = $_SESSION['recommendationID'];

// Connect to database
$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$column = NULL;

if(isset($_POST['fractions']))
{
	$column = 'math1';
}
elseif(isset($_POST['multiplication']))
{
	$column = 'math2';
}
elseif(isset($_POST['division']))
{
	$column = 'math3';
}
 
$query = "SELECT $column FROM recommendations WHERE id = $recommendationKey";
$result= $con->query($query);

$recommendationInfo = $result->fetch_array(MYSQLI_ASSOC);

$worksheetName = $recommendationInfo[$column];

header("Location: /worksheets/$worksheetName");


mysqli_close($con);


?>
