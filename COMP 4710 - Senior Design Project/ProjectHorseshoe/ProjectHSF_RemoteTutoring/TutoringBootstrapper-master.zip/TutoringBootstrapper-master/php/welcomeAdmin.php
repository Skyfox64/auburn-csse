<?php

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$query1 = "SELECT id, first_name, last_name, online, partner ";
$query1 .= "FROM users ";
$query1 .= "WHERE type = 'student'";
$query1 .= "ORDER BY last_name;";
$students = $con->query($query1);

$query2 = "SELECT id, first_name, last_name, partner ";
$query2 .= "FROM users ";
$query2 .= "WHERE type = 'tutor' AND online = '1' AND partner = '0'";
$query2 .= "ORDER BY last_name;";
$tutors = $con->query($query2);

$i = 0;
?>

<!DOCTYPE html>
<meta charset="UTF-8">

<html>
	<head>
		<meta content="text/html;charset=utf-8" http-equiv="Content-Type">
		<meta content="utf-8" http-equiv="encoding">
		<link rel="stylesheet" type="text/css" href="/bootstrap/css/bootstrap.min.css" media="screen" />
		<link rel="stylesheet" type="text/css" href="/css/superhero.css"/>
		<link rel="stylesheet" type="text/css" href="/css/horseshoe.css"/>
		<title>
			Welcome!
		</title>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<h1 style="text-align:center;">Roster</h1>
			</div>
			<div class="row">
				<div class="well vertical-align col-xs-8 welcomeSummary">
					<table class="table table-bordered table-hover">
						<tr>
							<th>Children</th>
							<th>Present</th>
							<th>
								Remote Tutors
								<span id='refreshTutors' class='glyphicon glyphicon-refresh' aria-hidden='true'></span>
							</th>
							<th>In Session</th>
						</tr>
				<?php
					while ($student = $students->fetch_array(MYSQLI_ASSOC))
					{
						$studentId = "student" . $student['id'];
						$lastName = ucfirst($student['last_name']);
						$firstName = ucfirst($student['first_name']);
						$partner = $student['partner'];
						
						echo "<tr id=$studentId>";
						
						echo "<td>$lastName, $firstName</td>";
						if($student['online'])
						{
							echo "<td><span class='glyphicon glyphicon-ok' aria-hidden='true'></span></td>";
						}
						else
						{
							echo "<td><span class='glyphicon glyphicon-remove' aria-hidden='true'></span></td>";
						}						
						echo "<td>";

						// If matched with a partner, display partner
						if($partner > 0)
						{
							$query8 = "SELECT last_name, first_name ";
							$query8 .= "FROM users ";
							$query8 .= "WHERE id = $partner;";
							
							mysqli_data_seek($tutors, 0);
							$tutorNameArr = $con->query($query8);
							$tutor = $tutorNameArr->fetch_array(MYSQLI_ASSOC);
							$tutorLast = ucfirst($tutor['last_name']);
							$tutorFirst = ucfirst($tutor['first_name']);
							
							echo "<div>";
							echo "<span class='tutorName'>$tutorLast, $tutorFirst</span>";
							echo "<span class='tutorId' style = 'display:none'>$partner</span>";
							echo "</div>";
							echo "<select class='tutorList' style = 'display:none' name='tutors'>";
						}
						else
						{
							echo "<div>";
							echo "<span class='tutorName' style = 'display:none'></span>";
							echo "<span class='tutorId' style = 'display:none'></span>";
							echo "</div>";
							echo "<select class='tutorList' name='tutors'>";
						}
						echo "<option value=0>No Tutor</option>";
						mysqli_data_seek($tutors, 0);
						while($tutor = $tutors->fetch_array(MYSQLI_ASSOC))
						{
							$tutorID = $tutor['id'];
							$tutorLast = ucfirst($tutor['last_name']);
							$tutorFirst = ucfirst($tutor['first_name']);
							echo "<option value=$tutorID>$tutorLast, $tutorFirst</option>";
						}
						echo "</select>";
						
						echo "</td>";
						if($student['partner'])
						{
							echo "<td><button type='button' class='btn-sm btn-danger disconnectBtn'";
						}
						else
						{
							echo "<td><button type='button' class='btn-sm btn-success connectBtn'";
						}
						// disable connect button if student is not checked in
						if(!$student['online'])
							{
								echo "disabled='disabled'";
							}
							echo "></button>";
						
						echo "</tr>";
						$i++;
					}
					mysqli_close($con);
					?>
						</tr>
					</table>
				</div>
			</div>
		</div>
	</body>
	<footer>
		<script src="/js/jquery2.2.0.js"></script>
		<script src="/js/welcomeAdmin.js"></script>
	</footer>
</html>
