<?php
session_start();

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$userId = $_SESSION['userID'];

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$query = "SELECT type, partner ";
$query .= "FROM users ";
$query .= "WHERE id = $userId;";
$result= $con->query($query);

$resourceQuery = "SELECT subject FROM recommendations;";
$recommedations = $con->query($resourceQuery);


mysqli_close($con);

$recommedation = $recommedations->fetch_array(MYSQLI_ASSOC);
$subject = $recommedation['subject'];


$studentInfo = $result->fetch_array(MYSQLI_ASSOC);

$userType = $studentInfo["type"];
$partnerId = $studentInfo["partner"];

// Only connect if matched with a partner.
if($partnerId != 0)
{
	/* If tutor, use your own id to join talky.io
	 * otherwise you are a student and should use 
	 * the tutor's id to join talky.io.
	 */
	if ($userType == 'tutor')
	{
		$data = json_encode(array($userId, $subject));
		echo $data;
	}
	elseif($userType == 'student')
	{
		$data = json_encode(array($partnerId, $subject));
		echo $data;
	}
}

?>