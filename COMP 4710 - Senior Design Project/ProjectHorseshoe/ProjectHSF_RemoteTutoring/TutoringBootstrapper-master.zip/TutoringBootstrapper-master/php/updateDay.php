<?php
session_start();
// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$userId = $_SESSION['userID'];
$subject = strtolower($_REQUEST['subject']);

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$query = "UPDATE recommendations ";
$query .= "SET subject = '$subject';";
$con->query($query);

echo $subject;

mysqli_close($con);
?>