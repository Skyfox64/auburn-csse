<?php

// Database Variables
$db_username="projhors_admin";
$db_password="seniorDesign2016";
$database="projhors_data";
$result=1;

$con = mysqli_connect('localhost',$db_username,$db_password,$database) or die ( "Failed to connect to MySQL: " .mysqli_connect_errno());

$db=mysqli_select_db($con, $database) or die( "Failed to connect to MySQL: ".mysqli_connect_errno());

$query = "SELECT id, first_name, last_name, partner ";
$query .= "FROM users ";
$query .= "WHERE type = 'tutor' AND online = '1' AND partner = '0'";
$query .= "ORDER BY last_name;";
$tutors = $con->query($query);

mysqli_close($con);

while($tutor = $tutors->fetch_array(MYSQLI_ASSOC))
{
	$tutorID = $tutor['id'];
	$tutorLast = ucfirst($tutor['last_name']);
	$tutorFirst = ucfirst($tutor['first_name']);
	echo "<option value=$tutorID>$tutorLast, $tutorFirst</option>";
}


?>