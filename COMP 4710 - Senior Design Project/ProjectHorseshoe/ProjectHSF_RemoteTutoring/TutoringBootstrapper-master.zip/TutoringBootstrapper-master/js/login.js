$(document).ready(function()
{
	var url = window.location.href;
	if (url.search('false') > 0)
	{
		$(".errorMsg").css("display", "block");
		console.log("invalid");
	}
	else
	{
		$(".errorMsg").css("display", "none");
		console.log("valid");
	}
});