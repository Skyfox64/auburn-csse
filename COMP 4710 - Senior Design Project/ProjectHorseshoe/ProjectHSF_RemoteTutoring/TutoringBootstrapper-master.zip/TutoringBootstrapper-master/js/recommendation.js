$(document).ready(function(){
	$("#subjectSelect").change(function(){
		var selectedSubject = $("#subjectSelect option:selected").val();
		var rowId = getRowId(this);
		var studentId = rowId.substring(8, rowId.length);
		console.log(selectedSubject);
		$.ajax({
			type: "post",
			data: "subject=" + selectedSubject + "&id=" + studentId,
			url: "../php/updateDay.php"
		}).done(function(subject) {
			//update dropdowns to subject, can only be done in PHP seperate later
			console.log("And the subject is " + subject);
		});
	});
	
	$(".resourceType").change(function(){
		var selectedType = $(this).children(":selected").val();
		var rowId = getRowId(this);
		var studentId = rowId.substring(8, rowId.length);
		
		if(selectedType == 'pdf')
		{
			//hide textbox
			$(rowId + " .resourceText").css("display", "none");
			//show dropdowns
			$(rowId + " .resourceDrop").css("display", "block");
			
		}
		else if(selectedType == 'link')
		{
			//hide dropdowns
			$(rowId + " .resourceDrop").css("display", "none");
			//show textbox
			$(rowId + " .resourceText").css("display", "block");
		}
	});
	
	$(".updateBtn").click(function(){
		var rowId = getRowId(this);
		var studentId = rowId.substring(8, rowId.length);
		/* Look inside row, if pdf is selected, send ddl value to 
		 * database, otherwise link is selected and text value
		 * should be sent to database.
		 */
		 console.log("Row ID " + rowId);
		 var selectedType = $(rowId + " select.resourceType").children(":selected").val();
		 var resource = "";
		 if(selectedType == 'pdf')
		 {
			 console.log("PDF activated");
			//get ddl value
			resource = $(rowId + " .resourceDrop").children(":selected").val();
		 }
		 else if (selectedType == 'link')
		 {
			 console.log("Link activated");
			//get text value
			resource = $(rowId + " .resourceText").val();
		 }
		 else{
			 console.log(selectedType);
		 }
		 $.ajax({
			type: "post",
			data: "resource=" + resource + "&id=" + studentId,
			url: "../php/updateRecommendation.php"
		}).done(function(data) {
			console.log("recommendation: " + data);
		});
	});
	
});

function getRowId(element)
{
	return "#" + $(element).closest("tr").attr('id');
}