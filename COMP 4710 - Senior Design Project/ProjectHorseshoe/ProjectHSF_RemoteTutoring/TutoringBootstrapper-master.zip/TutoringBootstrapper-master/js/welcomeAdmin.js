$(document).ready(function(){
	var checkedIn = "glyphicon glyphicon-ok";
	var checkedOut = "glyphicon glyphicon-remove";
	var connected = "btn-sm btn-success connectBtn";
	var disconnected = "btn-sm btn-danger disconnectBtn";
	
	$(".connectBtn").html("Connect");
	$(".disconnectBtn").html("Disconnect");
	
		

	$(".glyphicon-ok, .glyphicon-remove").click(function() {
		var currentClass = $(this).attr('class');
		var studentId = $(this).closest("tr").attr('id');
		
		var idNum = studentId.substring(7, studentId.length);
		
		if(currentClass == checkedIn)
		{
			$(this).removeClass(checkedIn);
			$(this).addClass(checkedOut);
			$.ajax({
			type: "post",
			data: "attendance=0&userId=" + idNum,
			url: "../php/updateRoster.php",
			always: function(){
				//target better
				var myStuff = "#" + studentId + " button";
				console.log(myStuff);
				$(myStuff).prop('disabled', true);
			}
			});
		}
		else
		{
			$(this).removeClass(checkedOut);
			$(this).addClass(checkedIn);
			$.ajax({
			type: "post",
			data: "attendance=1&userId=" + idNum,
			url: "../php/updateRoster.php",
			always: function() {
				//target button
				var myStuff = "#" + studentId + " button";
				console.log(myStuff);
				$(myStuff).prop('disabled', false);
			}
			});
		}
	});
	
	
	$("#refreshTutors").click(function(){
		refreshTutors();
		console.log("Refreshing");
	});
	
	$(".connectBtn, .disconnectBtn").click(function() {
		var currentClass = $(this).attr('class');
		var studentId = $(this).closest("tr").attr('id');
		var studentSelector = "#" + studentId;
		var childId = studentId.substring(7, studentId.length);
		var tutorId = $(studentSelector + " .tutorList option:selected").val();
		var tutorName = $(studentSelector + " .tutorList option:selected").text();
		
		
		if(currentClass == connected)
		{
			$(this).removeClass(connected);
			$(this).addClass(disconnected);
			$(this).html("Disconnect");
			$(studentSelector + " .tutorList").css("display", "none");
			$(studentSelector + " .tutorId").html(tutorId);
			$(studentSelector + " .tutorName").css("display", "inline-block");
			$(studentSelector + " .tutorName").html(tutorName);
			
			connectPairings(childId, tutorId, 1);
		}
		else
		{
			$(this).removeClass(disconnected);
			$(this).addClass(connected);
			$(this).html("Connect");
			tutorId = $(studentSelector + " .tutorId").text();
			$(studentSelector + " .tutorList").css("display", "inline-block");
			$(studentSelector + " .tutorId").html("");
			$(studentSelector + " .tutorName").css("display", "none");
			$(studentSelector + " .tutorName").html("");
			
			connectPairings(childId, tutorId, 0);
		}
	}); 
	
});

function refreshTutors()
{
	$.ajax({
			type: "post",
			url: "../php/populateTutors.php",
			success: function(msg)
			{
				$(".tutorList").html(msg);
				$(".tutorList").prepend("<option value=0>No Tutor</option>").val(0);
			}
		}); 
}

function connectPairings(childId, tutorId, connectStatus)
{
	$.ajax({
		type: "post",
		data: "childId=" + childId + "&tutorId=" + tutorId + "&connecting=" + connectStatus,
		url: "../php/connectPairs.php"
	}).done(function(data) {
		// somehow cause change in student and tutor pages
		refreshTutors();
	});
}