function continueWelcome() 
{
	//transition to 'today' section
	$(".welcomeSummary").fadeOut("fast");
	$(".welcomeToday").css("visibility", "visible").fadeIn("slow");
}

//http://stackoverflow.com/questions/19491336/get-url-parameter-jquery-or-how-to-get-query-string-values-in-js
 
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};

$(document).ready(function(){
	var name = getUrlParameter('name');
	name = name.charAt(0).toUpperCase() + name.slice(1);
	$(".welcomeTag").text("Welcome " + name + "!");
	
	var type = getUrlParameter('type');
	type = type.charAt(0).toUpperCase() + type.slice(1);
	$("#lastLessonType").text("Subject: " + type);
	
	var task = getUrlParameter('task');
	$("#lastLessonName").text("Lesson: " + task);
	
	checkConnection();
	
	$("#continue").click(function(){
		$.ajax({
			type: "get",
			url: "../php/welcomeStudent.php"
		}).success(function(data){
			window.open(data, '_blank');
		});
	});
	
});

// Check conection status every ten seconds
function timeout()
{
	setTimeout(checkConnection, 10000);
}

function checkConnection()
{
	$.ajax({
		type: "get",
		dataType: 'json',
		url: "../php/connection.php"
	}).done(function(data){
		var arr = data;
		var roomNumber = arr[0];
		if(roomNumber)
		{
			var url = "https://talky.io/hsf" + roomNumber;
			window.location = url;
		}
	});
	timeout();
}
