function LaunchApp() 
{
	if (!document.all) 
	{
	  alert ("Available only with Internet Explorer.");
	  return;
	}
	var ws = new ActiveXObject("WScript.Shell");
	ws.Exec("C:\\Windows\\notepad.exe");
}