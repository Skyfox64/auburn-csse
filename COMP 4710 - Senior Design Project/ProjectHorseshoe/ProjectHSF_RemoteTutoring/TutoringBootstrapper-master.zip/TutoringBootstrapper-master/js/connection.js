$(document).ready(function(){
	checkConnection();
});

// Check conection status every ten seconds
function timeout()
{
	setTimeout(checkConnection, 10000);
}

function checkConnection()
{
	$.ajax({
		type: "get",
		dataType: 'json',
		url: "../php/connection.php"
	}).done(function(data){
		var arr = data;
		var roomNumber = arr[0];
		var subject = arr[1];
		console.log("Subject: " + subject);
		if(roomNumber)
		{
 			if(subject == 'reading')
			{
				var url = "https://talky.io/hsf" + roomNumber;
				window.open(url, '_blank');
				window.location = "https://read.amazon.com";
			}
			else
			{ 
				var url = "https://talky.io/hsf" + roomNumber;
				window.location = url;
			}
		}
	});
	timeout();
}
