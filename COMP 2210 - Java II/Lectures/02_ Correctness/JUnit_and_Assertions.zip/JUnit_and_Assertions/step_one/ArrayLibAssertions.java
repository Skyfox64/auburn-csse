

public class ArrayLibAssertions {

   public static void main(String[] args) {
      searchTest_null();
      searchTest_length0();
      searchTest_length1_found();
   
   }

   public static void searchTest_null() {
   
   }

   public static void searchTest_length0() {
   
   }

   public static void searchTest_length1_found() {
      int[] a = {2};
      int expected = 0;
      int actual = ArrayLib.search(a, 2);
      assert expected == actual;
   }

   public static void searchTest_length1_not_found() {
   
   }

}
