import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class ArrayLibTest {

   @Test public void searchTest_null() {
   
   }

   @Test public void searchTest_length0() {
   
   }

   @Test public void searchTest_length1_found() {
      int[] a = {2};
      int expected = 0;
      int actual = ArrayLib.search(a, 2);
      Assert.assertEquals(expected, actual);
   }

   @Test public void searchTest_length1_not_found() {
   
   }

}
