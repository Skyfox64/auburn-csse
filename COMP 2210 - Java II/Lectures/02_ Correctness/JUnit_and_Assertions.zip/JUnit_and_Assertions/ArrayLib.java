/**
* ArrayLib.java. Defines static utility methods on arrays.
*
* @author  Dean Hendrix (dh@auburn.edu)
* @version 2013-01-14
*
*/
public class ArrayLib {

/**
 * Returns the index of target in a or -1 if
 * target is not in a. In the case of duplicates,
 * the index nearest zero is returned. If a is null
 * or zero-length, this method throws an IllegalArgumentException.
 *
 * @param a       the array to be searched through
 * @param target  the value being searched for
 * @return        the location of target in a or -1 if not present
 * @throws        IllegalArgumentException if a is null or zero-length
 *
 */
   public static int search(int[] a, int target) {
      return -1;
   }

}