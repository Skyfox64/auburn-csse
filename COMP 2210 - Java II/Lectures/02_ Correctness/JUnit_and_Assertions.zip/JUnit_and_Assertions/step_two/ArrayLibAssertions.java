
public class ArrayLibAssertions {


   public static void main(String[] args) {
      searchTest_null();
      searchTest_length0();
      searchTest_length1_found();
      searchTest_length1_not_found();
   }

   public static void searchTest_null() {
      int[] a = null;
      try {
         ArrayLib.search(a, 2);
         assert false;
      }
      catch (IllegalArgumentException e) {
         assert true;
      }
   }

   public static void searchTest_length0() {
      int[] a = new int[0];
      try {
         ArrayLib.search(a, 2);
         assert false;
      }
      catch (IllegalArgumentException e) {
         assert true;
      }
   }

   public static void searchTest_length1_found() {
      int[] a = {2};
      int expected = 0;
      int actual = ArrayLib.search(a, 2);
      assert expected == actual;
   }
   
   
   public static void searchTest_length1_not_found() {
      int[] a = {2};
      int expected = -1;
      int actual = ArrayLib.search(a, 1);
      assert expected == actual;
   }

}
