import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class ArrayLibTest {



   @Test(expected=IllegalArgumentException.class) public void searchTest_null() {
      int[] a = null;
      ArrayLib.search(a, 2);
   }

   @Test public void searchTest_length0() {
      int a[] = new int[0];
      try {
         ArrayLib.search(a, 2);
         Assert.fail();
      }
      catch (IllegalArgumentException e) {
      // correct
      }
   }

   @Test public void searchTest_length1_found() {
      int[] a = {2};
      int expected = 0;
      int actual = ArrayLib.search(a, 2);
      Assert.assertEquals(expected, actual);
   }
   
   
   @Test public void searchTest_length1_not_found() {
      int[] a = {2};
      int expected = -1;
      int actual = ArrayLib.search(a, 1);
      Assert.assertEquals(expected, actual);
   }

}
