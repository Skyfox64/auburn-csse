import java.util.List;
import java.util.Scanner;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;

/**
 * Supports playing Dodgson's Word Ladder game.
 *
 * @author    John Carroll (jcc0044@auburn.edu)
 * @version   2014-04-08
 *
 */
public class Dodgson {

/**
 * Instantiate with words available in the specified
 * InputStream used as the game's lexicon.
 *
 * @param in   InputStream with words for lexicon
 *
 */
   public Dodgson(InputStream in) {
      Scanner s = 
            new Scanner(new BufferedReader(new InputStreamReader(in)));
      while (s.hasNext()) {
         String str = s.next();
         // store str in the lexicon here
         s.nextLine();
      }
   }
   

/**
 * Constructs a shortest length Dodgson sequence from
 * start to finish. If multiple sequences exist with
 * minimum length, no guarantee is made about which is
 * returned. If no sequence exists, an empty List is 
 * returned.
 *
 * @param start the starting word for the sequence
 * @param finish the ending word for the sequence
 * @return the minimum sequence from start to finish
 *
 */
   public List<String> getMinSequence(String start, String finish) {
      return null;
   }


/**
 * Checks the provided sequence of words to see if it
 * is a valid Dodgson sequence.
 *
 * @param ladder the word ladder to test
 * @return true if ladder is a Dodgson sequence, false otherwise
 *
 */
   public boolean isValidSequence(List<String> seq) {
      return false;
   }   
   
/**
 * Returns the Hamming distance between the two
 * given strings. The Hamming distance is the number of 
 * corresponding characters in the two strings that 
 * are different. If the two strings do not have the 
 * same length, the Hamming distance is defined to be -1.
 *
 * @param s1 the first string
 * @param s2 the second string
 * @return the Hamming distance between s1 and s2
 *
 */   
   public int hammingDistance(String s1, String s2) {
      return -99;
   }

 
/**
 * Checks to see if the given string is a word;
 * that is, if it is contained in the current lexicon.
 *
 * @param s the string to test
 * @return true if s is in the lexicon, false otherwise
 *
 */
   public boolean isWord(String s) {
      return false;
   }   
   
   
/**
 * Returns the number of words in the current lexicon.
 *
 * @return the number of words in the lexicon
 *
 */
   public int wordCount() {
      return -99;
   }   
   
   
}


